#' Hassediagramdf2
#'
#' Returns the Hasse diagram with: source of variation, degrees of freedom,
#' matrices of the quadratic forms for sums of squares and the contributions to
#' the expectations of mean squares,from structural formulas.
#'
#' @param units a structural formula of units as a character.
#' @param trt a structural formula of treatments as a character.
#' @param data data.frame containing the variables named in structural the
#'  formulas.
#' @param rightcolor the color of everything to the right of the dot in the
#' Hasse diagram. Default is "red".
#' @param titlehd tarãrã
#' @param subtitlehd tarãrã2
#'
#' @example
#' a definir
#'



#'@export
Hassediagramdf <- function(formula = NULL, data = NULL, rightcolor = "red",
                           titlehd = "Hasse diagram",
                           subtitlehd = "Levels & Degrees of freedom") {

  data <- datafactorfun(df = data)

  nn.formula <- nnfun(form = formula)

  X.formula <- Xfun(nn. = nn.formula, data = data)

  M.formula <- Mfun(X. = X.formula)

  marginality.formula <- marginalityfun(M.formula)

  hasse.formula <- hassefun(nn. = nn.formula, form = formula)

  arrow.formula <- arrowsfun(marginality.formula, hasse.formula)

  max_x.formula <- max(hasse.formula$x) + 10
  min_x.formula <- min(hasse.formula$x) - 10
  max_y.formula <- max(hasse.formula$y) + 10
  min_y.formula <- min(hasse.formula$y) - 10

  labels.formula <- parsetree5(formula)

  name.formula1 <- dplyr::mutate(
    hasse.formula,
    label_left_x  = .data$x - 1.5,
    label_right_x = .data$x + 1.5,
    label_y_left  = .data$y,
    label_y_right = .data$y,
    label_left  = stringr::str_replace_all(.data$name, ":", "^"),
    label_right = ifelse(
      .data$name == "Universe",
      "Mean",
      purrr::map_chr(.data$name, ~ matchfun(.x, labels.formula$term))
    )
  )

  name.formula2 <- dplyr::mutate(
    hasse.formula,
    label_left_x  = .data$x - 1.5,
    label_right_x = .data$x + 1.5,
    label_y_left  = .data$y + 4,
    label_y_right = .data$y + 4,
    label_left  = stringr::str_replace_all(.data$name, ":", "^"),
    label_right = ifelse(
      .data$name == "Universe",
      "Mean",
      purrr::map_chr(.data$name, ~ matchfun(.x, labels.formula$term))
    )
  )

  df.vector.formula <- dffun(M. = M.formula, marg = marginality.formula)

  df.vector.formula <- dplyr::mutate(
    hasse.formula,
    label_left_x  = .data$x - 2,
    label_right_x = .data$x + 2,
    label_y       = .data$y - 4,
    levelsanddf   = paste0("[", df.vector.formula$levels, ",", df.vector.formula$df, "]")
  )

  df.graph.formula <- ggplot2::ggplot(NULL, ggplot2::aes(x = c(0, 285), y = c(0, 650))) +
    ggplot2::geom_point(
      data = hasse.formula,
      ggplot2::aes(x = .data$x, y = .data$y),
      size = 4,
      color = "black"
    ) +
    ggplot2::geom_segment(
      data = arrow.formula,
      ggplot2::aes(
        x = .data$xini,
        y = .data$yini + 1.5,
        xend = .data$xend,
        yend = .data$yend - 1.5
      ),
      arrow = grid::arrow(length = grid::unit(0.2, "cm"), type = "open"),
      color = "black",
      linewidth = 0.7,
      alpha = 0.4
    ) +
  ggplot2::geom_text(
    data = name.formula2,
    ggplot2::aes(x = .data$label_right_x, y = .data$label_y_right, label = .data$label_right),
    hjust = 0,
    color = rightcolor
  ) +
  ggplot2::geom_text(
    data = df.vector.formula,
    ggplot2::aes(x = .data$label_right_x, y = .data$label_y, label = .data$levelsanddf),
    hjust = 0,
    color = rightcolor
  ) +
  ggplot2::xlim(min_x.formula, max_x.formula) +
  ggplot2::ylim(min_y.formula, max_y.formula) +
  ggplot2::theme_void() +
  ggplot2::labs(title = titlehd, subtitle = subtitlehd) +
  ggplot2::theme(
    plot.title = ggplot2::element_text(hjust = 0.5, size = 18, face = "bold"),
    plot.subtitle = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold"),
    axis.title = ggplot2::element_blank()
  )

graph.list <- list(
  df.graph.formula      = df.graph.formula
)

return(graph.list)
}
